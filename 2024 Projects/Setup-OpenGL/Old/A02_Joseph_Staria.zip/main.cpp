// Course: IGME 309
// Student Name: Joseph Staria
// Assignment Number: 02

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif

#include "PolyCreation.h"
#include <vector>
#include "main.h"

using namespace std;

float canvasSize[] = { 10.0f, 10.0f };
int rasterSize[] = { 600, 600 };

PolyCreation polyCreate;

vec2 mousePos;
bool leftButtonDown;
bool rightButtonDown;

void handleMouseButton(int button, int state, int x, int y)
{
	if (button == GLUT_LEFT_BUTTON)
		leftButtonDown = (state == GLUT_DOWN);

	else if (button == GLUT_RIGHT_BUTTON)
		rightButtonDown = (state == GLUT_DOWN);
}

void handleMouseMotion(int x, int y) {
	mousePos = vec2((float)x / rasterSize[0] * canvasSize[0], (rasterSize[1] - (float)y) / rasterSize[1] * canvasSize[1]);
}

void handlePassiveMotion(int x, int y) {
	mousePos = vec2((float)x / rasterSize[0] * canvasSize[0], (rasterSize[1] - (float)y) / rasterSize[1] * canvasSize[1]);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 27:
		exit(0);
	case 13:
		polyCreate.createPolygon();
	}
}
void init(void)
{

}

void update(void) 
{
	polyCreate.update(rightButtonDown, leftButtonDown, mousePos);

	glutPostRedisplay();
}

void display(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT);

	polyCreate.draw(mousePos);


	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glutSwapBuffers();
}

void reshape(int w, int h)
{
	rasterSize[0] = w;
	rasterSize[1] = h;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0f, canvasSize[0], 0.0f, canvasSize[1]);
	glViewport(0, 0, rasterSize[0], rasterSize[1]);

	glutPostRedisplay();
}

int main(int argc, char* argv[])
{
	init();
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowSize(rasterSize[0], rasterSize[1]);
	glutCreateWindow("Polygon Creation");

	glutKeyboardFunc(keyboard);
	glutMouseFunc(handleMouseButton);
	glutMotionFunc(handleMouseMotion);
	glutPassiveMotionFunc(handlePassiveMotion);

	glutReshapeFunc(reshape);
	glutDisplayFunc(display);
	
	glutIdleFunc(update);

	glutMainLoop();
	return 0;


}